package com.hcl.dbs.activityservice.util;

public interface DateValidator {
    boolean isValid(String dateStr);
}
